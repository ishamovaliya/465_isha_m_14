

<html> 
<head> <title> MY PERSONAL BIO DATA</title>  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css" />
            
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js" type="text/javascript" language="javascript"></script>
    
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
 <script src="js/wow.min.js" type="text/javascript"></script>
<link href="animate.css" rel="stylesheet" type="text/css" />



    <STYLE type="TEXT/CSS">
  
 .fullscreen_bg 
                { position:absolute;
                    background-size: cover;
                   
                    width: 100%;
                    height: 100%
                   z-index:;
                  margin-top:-23px;
                   
                   
                } 
                 
                .fullscreen_PG 
                {
                  
                  }  


                *{ margin: 0px;
                 padding: 0px;
                 font-family: sans-serif; 
                 color: rgb(255, 252, 252);}
                
             


          #Home
	            {
	                height:100%;
	                padding-bottom:40px;
	                color:rgb(128, 255, 0);
	                font-weight:bold; 
                  width: 100%;
                  
	            }
             
	            
	            #HomeRow
	            {
	                padding-bottom:7%;  
                  margin-top: 4%; 
	            }
	            #HomeRow a i.fa
	            {
	                color:#ffffff;
	            }
	            
	            #HomeRow div.col-lg-offset-3

	            {
	                background:rgba(0,0,0,0.7); 
                    
	                padding-top:20px;
	                padding-bottom:20px;
	                border-radius:5px;
	                box-shadow:0px 0px 20px rgb(175, 96, 96);   
	            }
                 .navbar ul li {  
                     list-style: none;
                     display: inline-block;
                     margin: 20  25px; 
                     margin-top: 5px;
                     margin-bottom: 15px; 
                     font-size: 17px;
                 }
               
                .navbar{ background-color:rgb(125, 15, 15); 
                    
				            
					height:50px;width:200px%;text-align:center;font-style: initial; }
                
                     #OB  { 
                           width: 100%; 
                           background-image: url('BG IMAGE.jpg');
                           background-attachment:fixed;
	                         
	                           background-repeat:no-repeat;
	                            background-size:cover;
                     } 
                     #OB div.col-lg-offset-3 
                        { 
                            width: 80%;
                             margin-LEFT: 190PX; 
                             

                        }



                        #Qualifications
	            {
	                background-attachment:fixed;
	                background-image:url('1771974.jpg');
	                background-repeat:no-repeat;
	                background-size:cover;
	                font-size:25px;
	                padding-bottom:40px;
	                color:#000000;
                    
	            }
	            #QualificationsRow
	            {
	                 margin-top:50px;
	                 margin-bottom:100px;
                   
	            }
	            #QualificationsRow div.col-lg-offset-1
	            {    
                 
                  margin-top: 3%;
	                padding:10px;
                    color: white;
	                background-color:rgba(0, 0, 0, 0.8);
	                border-radius:8px;
	                box-shadow:0px 0px 18px rgb(221, 240, 243);
	                
	            }
	            #Qualifications table
	            {
	                width:100%;
	                margin-top:50px;
	            }
	            #Qualifications table tr td
	            {
	                padding-bottom:20px;
	            }
	            #Qualifications table tr td:first-child
	            {
	                width:30%;
	                padding-left:10px;
	            }
                 

              #Skills
	            {
	                background-attachment:fixed;
	                background-image:url('skills.jpg');
	                background-repeat:no-repeat;
	                background-size:cover;
	                font-size:25px;
	                padding-bottom:40px;
	                color:#000000;
                    
	            }
              #SkillsRow
	            {
	                 margin-top:200px;
	                 margin-bottom:100px;
	            }
	            #SkillsRow div.col-lg-offset-5
	            {
	                padding:10px;
                    font-size: 20px;
                    
	               background-color: #000000;
	                border-radius:8px;
	                box-shadow:0px 0px 18px rgb(208, 187, 187);
	                opacity:0.8;
	            }
	            #Skills table
	            {
	                width:100%;
	                margin-top:50px;
	            }
	            #Skills table tr td
	            {
	                padding-bottom:20px;
	            }
	            #Skills table tr td:first-child
	            {
	                width:30%;
	                padding-left:10px;
	            }
	            




              #td
	            {   
	                background-attachment:fixed;
	                background-image:url('achivment.jpg');
	                background-repeat:no-repeat;
	                background-size:cover;
	                font-size:25px;
	                padding-bottom:40px;
	                color:#730c0c;
                    
	            }
                #td div.col-lg-offset-5
	            {
	               padding-bottom: 30px;
                     width: 60%;
        
	               background-color: #ff0f0f;
	                border-radius:8px;
	                box-shadow:0px 0px 18px rgb(208, 187, 187);
	                opacity:0.8;
	            }
                #td2 div.col-lg-offset-5
	            {   padding-bottom: 30px;
                     width: 60%;
                     margin-LEFT: 1%;
	               background-color: #ff0f0f;
	                border-radius:8px;
	                box-shadow:0px 0px 18px rgb(208, 187, 187);
	                opacity:0.8;
	            } 





                @media(max-width:768px)
	            {
	                .fullscreen_bg_video 
                    {
                        left:-160%;
                        width:260%;
                    }
                    #TechnicalSummary
                    {
                        height:auto;    
                    }
                }
                @media(max-width:992px)
                {
                    #HomeRow
	                {
	                 padding-top:17%;    
	                }    
	                #TechnicalSummaryRow
	                {
	                 padding-top:17%;    
	                }
                }

            </style>


            <script type="text/javascript">
                new WOW().init();
            </script>    

               
</style> 
</head> 
<body>  
  
      <div class="navbar">
      
       <ul> 
           <li>  <B style="font-size: 30PX; font-style: italic;  color: black; margin-left: -40PX;"> s <SUP>P</B>  </li>
         <li ><b style="font-size: 20px; margin-left: -30px; font-style: italic; color: bisque ;">Sandip Parmar A.</b> </li>  
         <li><a href="#HomeRow"> <b> <i class="fa fa-user" aria-hidden="true" style="margin-right:15px"></i>Intro</b></a> </li>   
         <li><a href="#OB "> <b> <i class="fa fa-object-group" aria-hidden="true" style="margin-right:15px"></i> Objective </b></a> </li>   
         <li><a href="#Qualifications"> <b><i class="fa fa-graduation-cap" aria-hidden="true"  style="margin-right:15px"></i>Education</b></a> </li>   
         <li><a href="#Skills"> <b><i class="fa fa-cogs" aria-hidden="true"  style="margin-right:15px"></i>Skills</b></a> </li>   
           
         <li><a href="#td"> <b> <i class="fa fa-futbol-o" aria-hidden="true" style="margin-right:15px"></i>Hobbies & Intrest</b></a> </li>   
         <li><a href="#td2"> <b> <i class="fa fa-trophy" aria-hidden="true"  style="margin-right:15px"></i>Achivments </b></a> </li> 
       </ul>

    

    <div  class="fullscreen_bg">
        <video src="BG VIDEO.mp4" autoplay  loop muted class="fullscreen_bg_video"> </video> 
         </div>  

        
         <div class="row" id="HomeRow">
          <div class="col-lg-offset-3 col-md-offset-3 col-sm-offset-2 col-lg-6 col-md-6 col-sm-8 col-xs-12 wow slideInDown" data-wow-duration="3s">
               <center><img src="sandip.jpg" height="300px" width="auto" alt="sandip" /></center>
               <center><h2>sandip parmar a.</h2></center>

               <div class="row">
                   <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-lg-5 col-md-5 col-sm-5">
                        <center><i class="fa fa-2x fa-phone"></i> +91- 6355806132</center>
                   </div>
                   <div class="col-lg-5 col-md-6 col-sm-6">
                        <center><i class="fa fa-2x fa-envelope"></i> <a href="sandipparmar2722@gmail.com" style="color:#ffffff;">sandipparmar2722@gmail.com</a></center>
                   </div>
               </div><hr/>
               <div class="row">
                  
                    <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-lg-10 col-md-10 col-sm-10">
                      <center><i class="fa fa-2x fa-map-marker"></i> 06, mahavir nagar socity ,near sugyan school,opp divy pabha aprtment,virat nagar odhav ,38</center>
                 </div>
                   </div>
               <hr/>
               <div class="row">
               <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-lg-10 col-md-10 col-sm-10">
               <center><a href="#"><i class="fa fa-2x fa-facebook-square"></i></a> &nbsp;<a href="#"><i class="fa fa-2x fa-twitter-square"></i></a> &nbsp;<a href="#"><i class="fa fa-2x fa-linkedin-square"></i></a> &nbsp;<a href="#"><i class="fa fa-2x fa-instagram"></i></a></center>
          </div>
     </div>
   </div>
 
      <BR>
    <BR>
    
    
    
      <div id="ob" class="container-fluid">
    <DIV style="margin-top: 50%;"> 
   <div class="OBJECT" id="OB">
    <div class="col-lg-offset-3 col-md-offset-3 col-sm-offset-2 col-lg-6 col-md-6 col-sm-8 col-xs-12 wow slideInDown" data-wow-duration="3s">
         
         <center>    <H1>   <i class="fa fa-object-group" aria-hidden="true" style="margin-right:15px; size: 30%;"> OBJECTIVE </i> </H1></center>

         <div class="OB">
                 <H3> “Hard-working, goal-oriented, and a team player seeking an opportunity to incorporate my skills and put them to use.” </H3> 
                  <H3>“I am looking for an entry-level position to kickstart my career and utilize my skills and expand my knowledge.”</H3>
                  <H3> “I aspire to work in a reputable organisation and utilize my skills to inflate my expertise.” </H3>
             </div>        
</div>
</div>
</DIV>
 </div>
 



<div id="Qualifications" class="container-fluid">
  <div class="row" id="QualificationsRow">
       <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-lg-6 col-md-6 col-sm-6 wow slideInLeft" data-wow-duration="3s">
            <br /><h2 class="text-center"><i class="fa fa-university"></i> Education Qualification</h2><hr />
            <table class="table table-responsive" style="color: rgb(212, 183, 183);">
                <tr>
                    <td>Year<br />2021- 2022</td>
                    <td>BCA PURSHUING 2ND SEM<br /> from COMPUTER APPLICATIONS <br />Silveroak University.</br> 1<SUP>ST </SUP> SEM RESULT </br> 8.56 SPI </td>
                </tr>
                <tr>
                    <td>Year<br />2020 - 2021</td>
                    <td>HSC<br /> from COMMERCE VIVEKAND SCHOOL <br /> GUJRAT BOARD</br>54</td>
                </tr>
                <tr>
                    <td>Year<br />2018-2020</td>
                    <td>SSC <br />from SARKARI MADHYAMIC SCHOOL ALAU<br />GUJRAT BOARD<br /> 56.83.</td>
                </tr>
              
            </table>
       </div>
  </div>
</div>



<div id="Skills" class="container-fluid">
  <div class="row" id="SkillsRow">
       <div class="col-lg-offset-5 col-md-offset-5 col-sm-offset-5 col-lg-6 col-md-6 col-sm-6 wow slideInRight" data-wow-duration="3s">
            <center><br /><h2><i class="fa fa-list-alt"></i> Technical Skills</h2><hr /></center>
            <table style="color: white;">





              
                <tr>
                    <td>PROGRAMING LANGUAGES :</td>
                    <td>C,[HTML=CSS,JAVA,] DBMS.</td>
                </tr>
                <tr>
                    <td>DATABASE:</td>
                    <td>ORACALE </td>
                </tr>
               
                <tr>
                    <td>COMPUTER RELATED:</td>
                    <td>POWER POINT, EXCEL ,MS WORD</td>
                </tr>   
                <tr>
                  <td>OTHER:</td>
                  <td>PHOTO EDITING,VIDEO EDITING, YOUTUBE VEDEO MAKING</td>
              </tr>
             
                 
                
    
            </table> 
          
             <center><br /><h2><i class="fa fa-cogs"></i> SOFT SKILLS</h2><hr /></center>
            <table style="color: white; " > 
              
              <tr>
               <td>  <CENTER> <h4>  <LI >GOOD COMMUNICATION  </LI></H4> </CENTER><BR> 
                  <BR>  
                  <CENTER>  <H4> <LI> GOOD FRENDLY BEHEVIER</LI></H4  > </CENTER>
                 </td> 
                
        
           </table>
 
       </div>
  </div>
</div>    
 
 
 
 
 
<div id="td" class="container-fluid">
  <div class="row" id="tdRow">
       <div class="col-lg-offset-5 col-md-offset-5 col-sm-offset-5 col-lg-6 col-md-6 col-sm-6 wow slideInRight" data-wow-duration="3s">
            <center><br /><h2><i class="fa fa-futbol-o" aria-hidden="true"></i>Hobbies & Intrest </h2><hr /></center>
            




               
                
                  <H3> <li> <b>HOBBIES:</b> </li></H3>
                <H3> playing games ,listning song ,programig,editing  <BR></H3> 
               
             
                
                    
                    
                   <LI><b>INTREST:</b></LI> 
                    <H3>Programing, new new reserch and explaining,reading,Etc </H3>
                
 
              </div>
          </div>
          
           <br>
            <div class="row" id="td2"> 
              <div class="col-lg-offset-5 col-md-offset-5 col-sm-offset-5 col-lg-6 col-md-6 col-sm-6 wow slideInRight" data-wow-duration="3s" >
                   <center><br /><h2><i class="fa fa-trophy"></i> ACHIVMENT </h2><hr /></center>
                  
                   <LI> 1-12<SUB></SUB> STD RESULTS </LI> </H3>

                   <LI> 4 SPORT CERTIFICATE </H3></LI>
                   <LI>  2 TIMES DRISTRICT LEVEL COMPITION </H3></LI>
                   
              </div>

            </div>
            </div>
      
             









</body>
</html>
